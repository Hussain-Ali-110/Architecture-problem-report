/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package business;

 

import Data.ProductDAO;

public class ProductService {
    private ProductDAO productDAO;

    public ProductService() {
        this.productDAO = new ProductDAO();   
    }
    public void addProduct(String productName, double price) {
        productDAO.saveProduct(productName, price);
        System.out.println("Product added: " + productName + "RS" + price);
    }
}

