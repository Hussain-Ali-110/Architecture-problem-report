/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package business;

 

import Data.UserDAO;

public class UserService {
    private UserDAO userDAO;

    public UserService() {
        this.userDAO = new UserDAO();  
    }
    public void loginUser(String username, String password) {
        if (userDAO.isUserValid(username, password)) {
            System.out.println("User logged in: " + username);
        } else {
            System.out.println("Invalid credentials for user: " + username);
        }
    }
}
