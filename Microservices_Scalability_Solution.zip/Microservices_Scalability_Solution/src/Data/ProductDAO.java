/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Data;

 

public class ProductDAO {
    public void saveProduct(String productName, double price) {
        System.out.println("Product saved: " + productName + " ,RS" + price);
    }
}
