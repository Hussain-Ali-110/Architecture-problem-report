/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Presentation;

import business.UserService;
import business.ProductService;

public class MicroservicesApplication {
    public static void main(String[] args) {
        UserService userService = new UserService();
        ProductService productService = new ProductService();
        System.out.println("User Login...");
        userService.loginUser("Tahir Orakzai", "password123");
        System.out.println("Add Product...");
        productService.addProduct("Laptop", 18000.50);
    }
}
